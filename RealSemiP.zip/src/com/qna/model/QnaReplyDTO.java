package com.qna.model;

public class QnaReplyDTO {
	private int qna_rno;
	private int qna_bno;
	private String qna_rewriter;
	private String qna_recont;
	private String qna_redate;
	private String qna_reupdate;
	
	public int getQna_rno() {
		return qna_rno;
	}
	
	public void setQna_rno(int qna_rno) {
		this.qna_rno = qna_rno;
	}
	
	public int getQna_bno() {
		return qna_bno;
	}
	
	public void setQna_bno(int qna_bno) {
		this.qna_bno = qna_bno;
	}
	
	public String getQna_rewriter() {
		return qna_rewriter;
	}
	
	public void setQna_rewriter(String qna_rewriter) {
		this.qna_rewriter = qna_rewriter;
	}
	
	public String getQna_recont() {
		return qna_recont;
	}
	
	public void setQna_recont(String qna_recont) {
		this.qna_recont = qna_recont;
	}
	
	public String getQna_redate() {
		return qna_redate;
	}
	
	public void setQna_redate(String qna_redate) {
		this.qna_redate = qna_redate;
	}
	
	public String getQna_reupdate() {
		return qna_reupdate;
	}
	
	public void setQna_reupdate(String qna_reupdate) {
		this.qna_reupdate = qna_reupdate;
	}
}
